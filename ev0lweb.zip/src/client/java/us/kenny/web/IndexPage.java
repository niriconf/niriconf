package us.kenny.web;

/**
 * Holds the single static HTML page served at {@code /} by
 * {@link WebConfigServer}. Kept in its own file so the server class stays
 * readable; the page itself is plain HTML/CSS/JS (no build step, no
 * framework) since it's served directly from the mod with nothing to
 * compile.
 */
final class IndexPage {
    private IndexPage() {
    }

    static final String HTML = """
            <!doctype html>
            <html lang="en">
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>ev0l :: config</title>
            <style>
              :root {
                --bg: #0b0d10;
                --surface: #131720;
                --surface-2: #1a1f2a;
                --border: #232a36;
                --text: #e7e9ec;
                --text-dim: #828a96;
                --accent: #36d399;
                --accent-dim: rgba(54, 211, 153, 0.16);
                --danger: #ff6b6b;
                --mono: ui-monospace, "SF Mono", "Cascadia Code", Consolas, monospace;
                --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              }

              * { box-sizing: border-box; }

              body {
                margin: 0;
                background: var(--bg);
                color: var(--text);
                font-family: var(--sans);
                min-height: 100vh;
              }

              .wrap {
                max-width: 640px;
                margin: 0 auto;
                padding: 40px 20px 80px;
              }

              header {
                display: flex;
                align-items: baseline;
                justify-content: space-between;
                margin-bottom: 28px;
                padding-bottom: 16px;
                border-bottom: 1px solid var(--border);
              }

              .brand {
                font-family: var(--mono);
                font-size: 20px;
                font-weight: 600;
                letter-spacing: -0.02em;
              }

              .brand .dim { color: var(--text-dim); font-weight: 400; }

              .status {
                display: flex;
                align-items: center;
                gap: 7px;
                font-family: var(--mono);
                font-size: 12px;
                color: var(--text-dim);
              }

              .status .dot {
                width: 7px;
                height: 7px;
                border-radius: 50%;
                background: var(--text-dim);
                transition: background 0.2s;
              }

              .status.online .dot { background: var(--accent); box-shadow: 0 0 6px var(--accent); }
              .status.offline .dot { background: var(--danger); }

              .card {
                background: var(--surface);
                border: 1px solid var(--border);
                border-radius: 10px;
                margin-bottom: 14px;
                overflow: hidden;
              }

              .card-head {
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 12px;
                padding: 16px 18px;
              }

              .card-head .name {
                font-family: var(--mono);
                font-size: 15px;
                font-weight: 600;
              }

              .card-head .desc {
                font-size: 12.5px;
                color: var(--text-dim);
                margin-top: 4px;
                line-height: 1.4;
              }

              .settings {
                border-top: 1px solid var(--border);
                background: var(--surface-2);
              }

              .setting-row {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
                padding: 13px 18px;
                border-bottom: 1px solid var(--border);
              }

              .setting-row:last-child { border-bottom: none; }

              .setting-row.disabled { opacity: 0.45; }

              .setting-label {
                min-width: 0;
              }

              .setting-label .key {
                font-family: var(--mono);
                font-size: 13px;
              }

              .setting-label .desc {
                font-size: 11.5px;
                color: var(--text-dim);
                margin-top: 2px;
                line-height: 1.4;
              }

              .control { flex-shrink: 0; }

              input[type="text"], input[type="number"] {
                background: var(--bg);
                border: 1px solid var(--border);
                color: var(--text);
                font-family: var(--mono);
                font-size: 13px;
                padding: 6px 9px;
                border-radius: 6px;
                width: 160px;
                outline: none;
                transition: border-color 0.15s;
              }

              input[type="text"]:focus, input[type="number"]:focus {
                border-color: var(--accent);
              }

              input[type="number"] { width: 90px; }

              select {
                background: var(--bg);
                border: 1px solid var(--border);
                color: var(--text);
                font-family: var(--mono);
                font-size: 13px;
                padding: 6px 9px;
                border-radius: 6px;
                width: 160px;
                outline: none;
              }

              .multiselect {
                position: relative;
                width: 180px;
              }

              .ms-toggle {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 8px;
                width: 100%;
                background: var(--bg);
                border: 1px solid var(--border);
                color: var(--text);
                font-family: var(--mono);
                font-size: 13px;
                padding: 6px 9px;
                border-radius: 6px;
                cursor: pointer;
                transition: border-color 0.15s;
              }

              .multiselect.open .ms-toggle, .ms-toggle:hover { border-color: var(--accent); }

              .ms-caret { color: var(--text-dim); font-size: 10px; }

              .ms-panel {
                display: none;
                position: absolute;
                top: calc(100% + 4px);
                right: 0;
                z-index: 10;
                width: 220px;
                max-height: 220px;
                overflow-y: auto;
                background: var(--surface);
                border: 1px solid var(--border);
                border-radius: 8px;
                padding: 6px;
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
              }

              .multiselect.open .ms-panel { display: block; }

              .ms-option {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 5px 6px;
                border-radius: 5px;
                font-size: 12.5px;
                font-family: var(--mono);
                cursor: pointer;
              }

              .ms-option:hover { background: var(--surface-2); }

              .ms-option input { accent-color: var(--accent); }

              /* toggle switch */
              .switch {
                position: relative;
                display: inline-block;
                width: 38px;
                height: 22px;
                flex-shrink: 0;
              }

              .switch input {
                opacity: 0;
                width: 0;
                height: 0;
              }

              .switch .track {
                position: absolute;
                inset: 0;
                background: var(--border);
                border-radius: 999px;
                cursor: pointer;
                transition: background 0.15s;
              }

              .switch .track::before {
                content: "";
                position: absolute;
                width: 16px;
                height: 16px;
                left: 3px;
                top: 3px;
                background: var(--text-dim);
                border-radius: 50%;
                transition: transform 0.15s, background 0.15s;
              }

              .switch input:checked + .track {
                background: var(--accent-dim);
              }

              .switch input:checked + .track::before {
                transform: translateX(16px);
                background: var(--accent);
              }

              footer {
                margin-top: 32px;
                text-align: center;
                font-size: 11.5px;
                color: var(--text-dim);
                font-family: var(--mono);
              }

              .toast {
                position: fixed;
                bottom: 22px;
                left: 50%;
                transform: translate(-50%, 12px);
                background: var(--surface-2);
                border: 1px solid var(--border);
                color: var(--text);
                font-family: var(--mono);
                font-size: 12.5px;
                padding: 9px 16px;
                border-radius: 8px;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.2s, transform 0.2s;
              }

              .toast.show {
                opacity: 1;
                transform: translate(-50%, 0);
              }

              .toast.error { border-color: var(--danger); color: var(--danger); }

              .empty {
                color: var(--text-dim);
                font-size: 13px;
                text-align: center;
                padding: 40px 0;
                font-family: var(--mono);
              }

              .section-title {
                font-family: var(--mono);
                font-size: 13px;
                color: var(--text-dim);
                text-transform: uppercase;
                letter-spacing: 0.06em;
                margin: 28px 0 10px;
              }

              .section-title:first-child { margin-top: 0; }

              .kb-row {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
                padding: 11px 18px;
                border-bottom: 1px solid var(--border);
                flex-wrap: wrap;
              }

              .kb-row:last-child { border-bottom: none; }

              .kb-name {
                font-family: var(--mono);
                font-size: 13px;
                min-width: 0;
              }

              .kb-vanilla {
                font-size: 11px;
                color: var(--text-dim);
                margin-top: 2px;
              }

              .kb-binds {
                display: flex;
                align-items: center;
                gap: 6px;
                flex-wrap: wrap;
              }

              .kb-chip {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                background: var(--bg);
                border: 1px solid var(--border);
                border-radius: 999px;
                padding: 4px 6px 4px 10px;
                font-family: var(--mono);
                font-size: 12px;
              }

              .kb-chip button {
                background: none;
                border: none;
                color: var(--danger);
                cursor: pointer;
                font-size: 13px;
                line-height: 1;
                padding: 2px 4px;
              }

              .kb-add {
                background: var(--surface);
                border: 1px dashed var(--border);
                color: var(--text-dim);
                font-family: var(--mono);
                font-size: 12px;
                border-radius: 999px;
                padding: 4px 12px;
                cursor: pointer;
              }

              .kb-add:hover { color: var(--text); border-color: var(--accent); }

              .kb-add.capturing {
                color: var(--accent);
                border-color: var(--accent);
                border-style: solid;
              }

              .kb-category {
                background: var(--surface-2);
                border-top: 1px solid var(--border);
                padding: 8px 18px;
                font-family: var(--mono);
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 0.08em;
                text-transform: uppercase;
                color: var(--accent);
              }

              .kb-category:first-child { border-top: none; }

              .kb-panel-overlay {
                position: fixed;
                inset: 0;
                z-index: 100;
                display: none;
              }

              .kb-panel-overlay.open { display: block; }

              .kb-panel {
                position: fixed;
                background: var(--surface);
                border: 1px solid var(--border);
                border-radius: 12px;
                padding: 20px;
                min-width: 260px;
                max-width: 340px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.5);
                z-index: 101;
                transform: scale(0.95) translateY(6px);
                opacity: 0;
                transition: transform 0.18s cubic-bezier(0.34,1.56,0.64,1), opacity 0.15s ease;
                pointer-events: none;
              }

              .kb-panel.open {
                transform: scale(1) translateY(0);
                opacity: 1;
                pointer-events: auto;
              }

              .kb-panel-title {
                font-family: var(--mono);
                font-size: 13px;
                font-weight: 600;
                margin-bottom: 4px;
                padding-right: 24px;
              }

              .kb-panel-sub {
                font-size: 11.5px;
                color: var(--text-dim);
                margin-bottom: 16px;
              }

              .kb-panel-section {
                font-family: var(--mono);
                font-size: 10px;
                color: var(--text-dim);
                text-transform: uppercase;
                letter-spacing: 0.07em;
                margin-bottom: 8px;
              }

              .kb-panel-chips {
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
                min-height: 28px;
              }

              .kb-panel-add {
                background: var(--surface-2);
                border: 1px dashed var(--border);
                color: var(--text-dim);
                font-family: var(--mono);
                font-size: 12px;
                border-radius: 999px;
                padding: 5px 14px;
                cursor: pointer;
                width: 100%;
                text-align: center;
                margin-top: 10px;
              }

              .kb-panel-add:hover { color: var(--text); border-color: var(--accent); }
              .kb-panel-add.capturing { color: var(--accent); border-color: var(--accent); border-style: solid; }

              .kb-panel-close {
                position: absolute;
                top: 14px;
                right: 14px;
                background: none;
                border: none;
                color: var(--text-dim);
                font-size: 16px;
                cursor: pointer;
                line-height: 1;
                padding: 2px 5px;
              }

              .kb-panel-close:hover { color: var(--text); }
            </style>
            </head>
            <body>
              <div class="wrap">
                <header>
                  <div class="brand">ev0l<span class="dim">.config</span></div>
                  <div class="status" id="status"><span class="dot"></span><span id="statusText">connecting</span></div>
                </header>
                <div class="section-title">modules</div>
                <div id="modules"></div>
                <div class="section-title">keybinds</div>
                <div class="card" id="keybinds"></div>
                <footer>served locally &middot; 127.0.0.1 only</footer>
              </div>
              <div class="toast" id="toast"></div>
              <div class="kb-panel-overlay" id="kbPanelOverlay">
                <div class="kb-panel" id="kbPanel">
                  <button class="kb-panel-close" id="kbPanelClose">&times;</button>
                  <div class="kb-panel-title" id="kbPanelTitle"></div>
                  <div class="kb-panel-sub" id="kbPanelSub"></div>
                  <div class="kb-panel-section">multi-binds</div>
                  <div class="kb-panel-chips" id="kbPanelChips"></div>
                  <button class="kb-panel-add" id="kbPanelAdd">+ add bind</button>
                </div>
              </div>

              <script>
                const POLL_MS = 4000;
                let lastConfig = null;
                let toastTimer = null;
                const openMultiSelects = new Set();

                function esc(s) {
                  return String(s).replace(/[&<>"']/g, c => ({
                    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
                  }[c]));
                }

                function setStatus(online, text) {
                  const el = document.getElementById("status");
                  el.className = "status " + (online ? "online" : "offline");
                  document.getElementById("statusText").textContent = text;
                }

                function showToast(message, isError) {
                  const toast = document.getElementById("toast");
                  toast.textContent = message;
                  toast.className = "toast show" + (isError ? " error" : "");
                  clearTimeout(toastTimer);
                  toastTimer = setTimeout(() => { toast.className = "toast"; }, 1600);
                }

                function isFocused(id) {
                  return document.activeElement && document.activeElement.id === id;
                }

                function renderSetting(moduleName, moduleEnabled, setting) {
                  const id = "setting-" + moduleName + "-" + setting.name;
                  let control;
                  if (setting.type === "boolean") {
                    control = `
                      <label class="switch">
                        <input type="checkbox" id="${id}" ${setting.value ? "checked" : ""}
                          data-module="${esc(moduleName)}" data-setting="${esc(setting.name)}" data-kind="boolean">
                        <span class="track"></span>
                      </label>`;
                  } else if (setting.type === "number") {
                    const focused = isFocused(id);
                    control = `
                      <input type="number" id="${id}" ${focused ? "" : `value="${esc(setting.value)}"`}
                        min="${esc(setting.min)}" max="${esc(setting.max)}" step="any"
                        data-module="${esc(moduleName)}" data-setting="${esc(setting.name)}" data-kind="number">`;
                  } else if (setting.type === "multiselect") {
                    const selected = new Set(setting.value);
                    const isOpen = openMultiSelects.has(id);
                    const summary = setting.value.length === 0
                      ? "none selected"
                      : setting.value.length + " selected";
                    const optionsHtml = setting.options.map(opt => `
                      <label class="ms-option">
                        <input type="checkbox" data-kind="multiselect-option"
                          data-module="${esc(moduleName)}" data-setting="${esc(setting.name)}"
                          data-value="${esc(opt)}" ${selected.has(opt) ? "checked" : ""}>
                        <span>${esc(opt)}</span>
                      </label>`).join("");
                    control = `
                      <div class="multiselect${isOpen ? " open" : ""}" data-ms-id="${id}">
                        <button type="button" class="ms-toggle" data-kind="multiselect-toggle" data-ms-id="${id}">
                          <span>${esc(summary)}</span><span class="ms-caret">&#9662;</span>
                        </button>
                        <div class="ms-panel">${optionsHtml}</div>
                      </div>`;
                  } else if (setting.name === "font") {
                    const presets = ["default", "uniform", "alt"];
                    const isPreset = presets.includes(setting.value);
                    const focused = isFocused(id + "-custom");
                    const selectValue = isPreset ? setting.value : "custom";
                    const options = presets.map(p =>
                      `<option value="${p}" ${selectValue === p ? "selected" : ""}>${p[0].toUpperCase() + p.slice(1)}</option>`
                    ).join("") + `<option value="custom" ${selectValue === "custom" ? "selected" : ""}>Custom&hellip;</option>`;
                    control = `
                      <select id="${id}" data-module="${esc(moduleName)}" data-setting="${esc(setting.name)}" data-kind="font-select">
                        ${options}
                      </select>
                      <input type="text" id="${id}-custom" ${focused ? "" : `value="${esc(setting.value)}"`}
                        placeholder="namespace:path" style="${selectValue === "custom" ? "" : "display:none;"}margin-top:6px;"
                        data-module="${esc(moduleName)}" data-setting="${esc(setting.name)}" data-kind="text">`;
                  } else {
                    const focused = isFocused(id);
                    control = `
                      <input type="text" id="${id}" ${focused ? "" : `value="${esc(setting.value)}"`}
                        data-module="${esc(moduleName)}" data-setting="${esc(setting.name)}" data-kind="text">`;
                  }
                  return `
                    <div class="setting-row ${moduleEnabled ? "" : "disabled"}">
                      <div class="setting-label">
                        <div class="key">${esc(setting.name)}</div>
                        <div class="desc">${esc(setting.description)}</div>
                      </div>
                      <div class="control">${control}</div>
                    </div>`;
                }

                function renderModule(mod) {
                  const settingsHtml = mod.settings.length
                    ? `<div class="settings">${mod.settings.map(s => renderSetting(mod.name, mod.enabled, s)).join("")}</div>`
                    : "";
                  return `
                    <div class="card">
                      <div class="card-head">
                        <div>
                          <div class="name">${esc(mod.name)}</div>
                          <div class="desc">${esc(mod.description)}</div>
                        </div>
                        <label class="switch">
                          <input type="checkbox" ${mod.enabled ? "checked" : ""}
                            data-module="${esc(mod.name)}" data-kind="enabled">
                          <span class="track"></span>
                        </label>
                      </div>
                      ${settingsHtml}
                    </div>`;
                }

                function render(config) {
                  lastConfig = config;
                  const root = document.getElementById("modules");
                  if (!config.modules.length) {
                    root.innerHTML = '<div class="empty">no modules registered</div>';
                    return;
                  }
                  root.innerHTML = config.modules.map(renderModule).join("");
                }

                async function load() {
                  try {
                    const res = await fetch("/api/config");
                    if (!res.ok) throw new Error("HTTP " + res.status);
                    const config = await res.json();
                    setStatus(true, "connected");
                    render(config);
                  } catch (e) {
                    setStatus(false, "disconnected");
                  }
                }

                async function applyChange(payload) {
                  try {
                    const res = await fetch("/api/config", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify(payload)
                    });
                    const body = await res.json();
                    if (!res.ok) throw new Error(body.error || ("HTTP " + res.status));
                    setStatus(true, "connected");
                    render(body);
                    showToast("saved", false);
                  } catch (e) {
                    setStatus(false, "disconnected");
                    showToast("failed to save: " + e.message, true);
                  }
                }

                document.getElementById("modules").addEventListener("change", (e) => {
                  const t = e.target;
                  if (!t.dataset.module) return;
                  if (t.dataset.kind === "enabled") {
                    applyChange({ module: t.dataset.module, enabled: t.checked });
                  } else if (t.dataset.kind === "boolean") {
                    applyChange({ module: t.dataset.module, setting: t.dataset.setting, value: t.checked });
                  } else if (t.dataset.kind === "number") {
                    const value = parseFloat(t.value);
                    if (!Number.isNaN(value)) {
                      applyChange({ module: t.dataset.module, setting: t.dataset.setting, value });
                    }
                  } else if (t.dataset.kind === "font-select") {
                    if (t.value === "custom") {
                      const customInput = document.getElementById(t.id + "-custom");
                      customInput.style.display = "";
                      customInput.focus();
                    } else {
                      applyChange({ module: t.dataset.module, setting: t.dataset.setting, value: t.value });
                    }
                  } else if (t.dataset.kind === "multiselect-option") {
                    const group = t.closest(".multiselect");
                    const value = Array.from(group.querySelectorAll('input[data-kind="multiselect-option"]:checked'))
                      .map(cb => cb.dataset.value);
                    applyChange({ module: t.dataset.module, setting: t.dataset.setting, value });
                  }
                });

                document.getElementById("modules").addEventListener("click", (e) => {
                  const toggle = e.target.closest('[data-kind="multiselect-toggle"]');
                  if (!toggle) return;
                  const id = toggle.dataset.msId;
                  if (openMultiSelects.has(id)) {
                    openMultiSelects.delete(id);
                  } else {
                    openMultiSelects.clear();
                    openMultiSelects.add(id);
                  }
                  render(lastConfig);
                });

                document.addEventListener("click", (e) => {
                  if (e.target.closest(".multiselect")) return;
                  if (openMultiSelects.size) {
                    openMultiSelects.clear();
                    render(lastConfig);
                  }
                });

                document.getElementById("modules").addEventListener("blur", (e) => {
                  const t = e.target;
                  if (t.dataset.kind === "text") {
                    applyChange({ module: t.dataset.module, setting: t.dataset.setting, value: t.value });
                  }
                }, true);

                document.getElementById("modules").addEventListener("keydown", (e) => {
                  if (e.key === "Enter" && e.target.dataset && e.target.dataset.kind === "text") {
                    e.target.blur();
                  }
                });

                load();
                setInterval(load, POLL_MS);

                // ------------------------------------------------------- keybinds

                let lastKeybinds = null;
                let capturingAction = null;    // for inline capture (unused now - panel handles)
                let panelCapturing = false;    // capture mode inside panel
                let panelAction = null;        // which action the open panel is for

                function mcKeyFromCode(code) {
                  const special = {
                    Space: "key.keyboard.space", Enter: "key.keyboard.enter", Tab: "key.keyboard.tab",
                    Backspace: "key.keyboard.backspace", CapsLock: "key.keyboard.caps.lock",
                    ShiftLeft: "key.keyboard.left.shift", ShiftRight: "key.keyboard.right.shift",
                    ControlLeft: "key.keyboard.left.control", ControlRight: "key.keyboard.right.control",
                    AltLeft: "key.keyboard.left.alt", AltRight: "key.keyboard.right.alt",
                    ArrowUp: "key.keyboard.up", ArrowDown: "key.keyboard.down",
                    ArrowLeft: "key.keyboard.left", ArrowRight: "key.keyboard.right",
                    Minus: "key.keyboard.minus", Equal: "key.keyboard.equal",
                    BracketLeft: "key.keyboard.left.bracket", BracketRight: "key.keyboard.right.bracket",
                    Semicolon: "key.keyboard.semicolon", Quote: "key.keyboard.apostrophe",
                    Comma: "key.keyboard.comma", Period: "key.keyboard.period", Slash: "key.keyboard.slash",
                    Backslash: "key.keyboard.backslash", Backquote: "key.keyboard.grave.accent",
                    Delete: "key.keyboard.delete", Insert: "key.keyboard.insert",
                    Home: "key.keyboard.home", End: "key.keyboard.end",
                    PageUp: "key.keyboard.page.up", PageDown: "key.keyboard.page.down",
                    NumLock: "key.keyboard.num.lock"
                  };
                  if (special[code]) return special[code];
                  if (/^Key[A-Z]$/.test(code)) return "key.keyboard." + code.slice(3).toLowerCase();
                  if (/^Digit[0-9]$/.test(code)) return "key.keyboard." + code.slice(5);
                  if (/^F([1-9]|1[0-9]|2[0-5])$/.test(code)) return "key.keyboard.f" + code.slice(1);
                  if (/^Numpad[0-9]$/.test(code)) return "key.keyboard.keypad." + code.slice(6);
                  return null;
                }

                function mcKeyFromMouseButton(button) {
                  return { 0: "key.mouse.left", 1: "key.mouse.middle", 2: "key.mouse.right",
                    3: "key.mouse.4", 4: "key.mouse.5" }[button] || null;
                }

                async function postKeybinds(payload) {
                  try {
                    const res = await fetch("/api/keybinds", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify(payload)
                    });
                    const body = await res.json();
                    if (!res.ok) throw new Error(body.error || ("HTTP " + res.status));
                    lastKeybinds = body;
                    renderKeybinds(body);
                    // refresh panel if open
                    if (panelAction) {
                      const kb = findKbByAction(body, panelAction);
                      if (kb) refreshPanelBindings(kb);
                    }
                    showToast("saved", false);
                  } catch (e) {
                    showToast("failed to save: " + e.message, true);
                  }
                }

                function addKeybind(action, key) {
                  postKeybinds({ action, key });
                }

                function removeKeybind(id) {
                  postKeybinds({ removeId: id });
                }

                function findKbByAction(data, action) {
                  for (const cat of (data.categories || [])) {
                    const found = (cat.keybinds || []).find(kb => kb.action === action);
                    if (found) return found;
                  }
                  return null;
                }

                // ---- right-click panel ----

                const panelOverlay = document.getElementById("kbPanelOverlay");
                const panel = document.getElementById("kbPanel");
                const panelTitle = document.getElementById("kbPanelTitle");
                const panelSub = document.getElementById("kbPanelSub");
                const panelChips = document.getElementById("kbPanelChips");
                const panelAddBtn = document.getElementById("kbPanelAdd");
                const panelClose = document.getElementById("kbPanelClose");

                function stopPanelCapturing() {
                  panelCapturing = false;
                  panelAddBtn.textContent = "+ add bind";
                  panelAddBtn.classList.remove("capturing");
                  document.removeEventListener("keydown", onPanelCaptureKeydown, true);
                  document.removeEventListener("mousedown", onPanelCaptureMousedown, true);
                  document.removeEventListener("contextmenu", onPanelCaptureContextMenu, true);
                }

                function onPanelCaptureKeydown(e) {
                  e.preventDefault();
                  if (e.key === "Escape") { stopPanelCapturing(); return; }
                  const key = mcKeyFromCode(e.code);
                  const action = panelAction;
                  stopPanelCapturing();
                  if (key) addKeybind(action, key);
                  else showToast("unrecognized key", true);
                }

                function onPanelCaptureMousedown(e) {
                  // Only capture if clicking outside panel
                  if (panel.contains(e.target)) return;
                  e.preventDefault();
                  const key = mcKeyFromMouseButton(e.button);
                  const action = panelAction;
                  stopPanelCapturing();
                  if (key) addKeybind(action, key);
                  else showToast("unrecognized mouse button", true);
                }

                function onPanelCaptureContextMenu(e) {
                  e.preventDefault();
                }

                function startPanelCapturing() {
                  panelCapturing = true;
                  panelAddBtn.textContent = "press a key\u2026 (esc to cancel)";
                  panelAddBtn.classList.add("capturing");
                  document.addEventListener("keydown", onPanelCaptureKeydown, true);
                  document.addEventListener("mousedown", onPanelCaptureMousedown, true);
                  document.addEventListener("contextmenu", onPanelCaptureContextMenu, true);
                }

                function refreshPanelBindings(kb) {
                  panelChips.innerHTML = kb.bindings.map(b => `
                    <span class="kb-chip">
                      ${esc(b.keyName)}
                      <button class="panel-remove" data-remove="${esc(b.id)}" title="remove">&times;</button>
                    </span>`).join("");
                  if (!kb.bindings.length) {
                    panelChips.innerHTML = '<span style="color:var(--text-dim);font-size:12px;font-family:var(--mono)">none</span>';
                  }
                }

                function openPanel(kb, anchorEl) {
                  panelAction = kb.action;
                  panelTitle.textContent = kb.displayName;
                  panelSub.textContent = "default: " + kb.vanillaKeyName;
                  refreshPanelBindings(kb);
                  stopPanelCapturing();

                  // Position panel near the row, keeping it on screen
                  const rect = anchorEl.getBoundingClientRect();
                  panel.style.top = "";
                  panel.style.left = "";
                  panel.style.right = "";
                  panel.style.bottom = "";

                  let top = rect.bottom + 6;
                  let left = rect.left;
                  // Keep on screen
                  const pw = 340, ph = 200;
                  if (left + pw > window.innerWidth - 16) left = window.innerWidth - pw - 16;
                  if (left < 16) left = 16;
                  if (top + ph > window.innerHeight - 16) top = rect.top - ph - 6;
                  panel.style.top = top + "px";
                  panel.style.left = left + "px";

                  panelOverlay.classList.add("open");
                  requestAnimationFrame(() => panel.classList.add("open"));
                }

                function closePanel() {
                  stopPanelCapturing();
                  panel.classList.remove("open");
                  setTimeout(() => {
                    panelOverlay.classList.remove("open");
                    panelAction = null;
                  }, 180);
                }

                panelClose.addEventListener("click", closePanel);

                panelOverlay.addEventListener("click", (e) => {
                  if (!panel.contains(e.target)) closePanel();
                });

                panelAddBtn.addEventListener("click", () => {
                  if (!panelCapturing) startPanelCapturing();
                });

                panelChips.addEventListener("click", (e) => {
                  const removeId = e.target.dataset.remove;
                  if (removeId) removeKeybind(removeId);
                });

                // ---- rendering ----

                function renderKeybindRow(kb) {
                  const chips = kb.bindings.map(b => `
                    <span class="kb-chip">
                      ${esc(b.keyName)}
                      <button data-remove="${esc(b.id)}" title="remove">&times;</button>
                    </span>`).join("");
                  const bindCount = kb.bindings.length;
                  const badge = bindCount > 0
                    ? `<span style="font-family:var(--mono);font-size:11px;color:var(--accent);margin-left:6px">${bindCount}</span>`
                    : "";
                  return `
                    <div class="kb-row" data-action="${esc(kb.action)}">
                      <div class="kb-name">
                        ${esc(kb.displayName)}${badge}
                        <div class="kb-vanilla">default: ${esc(kb.vanillaKeyName)}</div>
                      </div>
                      <div class="kb-binds">${chips}</div>
                    </div>`;
                }

                function renderKeybinds(data) {
                  if (!data) return;
                  lastKeybinds = data;
                  const root = document.getElementById("keybinds");
                  const cats = data.categories || [];
                  if (!cats.length || cats.every(c => !c.keybinds.length)) {
                    root.innerHTML = '<div class="empty">no keybinds found</div>';
                    return;
                  }
                  root.innerHTML = cats.map(cat => {
                    const rows = cat.keybinds.map(renderKeybindRow).join("");
                    return `<div class="kb-category">${esc(cat.category)}</div>${rows}`;
                  }).join("");
                }

                async function loadKeybinds() {
                  try {
                    const res = await fetch("/api/keybinds");
                    if (!res.ok) throw new Error("HTTP " + res.status);
                    renderKeybinds(await res.json());
                  } catch (e) {
                    // status indicator is already handled by the module poll
                  }
                }

                // Left-click to remove binds from inline chips
                document.getElementById("keybinds").addEventListener("click", (e) => {
                  const removeId = e.target.dataset.remove;
                  if (removeId) removeKeybind(removeId);
                });

                // Right-click on a kb-row to open the settings panel
                document.getElementById("keybinds").addEventListener("contextmenu", (e) => {
                  const row = e.target.closest(".kb-row");
                  if (!row) return;
                  e.preventDefault();
                  const action = row.dataset.action;
                  if (!action || !lastKeybinds) return;
                  const kb = findKbByAction(lastKeybinds, action);
                  if (kb) openPanel(kb, row);
                });

                loadKeybinds();
                setInterval(() => { if (!panelCapturing) loadKeybinds(); }, POLL_MS);
              </script>
            </body>
            </html>
            """;
}
