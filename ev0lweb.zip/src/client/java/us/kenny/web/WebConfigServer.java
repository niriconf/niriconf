package us.kenny.web;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.network.chat.Component;

import com.mojang.blaze3d.platform.InputConstants;

import us.kenny.ConfigManager;
import us.kenny.MultiKeyBindingClient;
import us.kenny.MultiKeyBindingManager;
import us.kenny.core.MultiKeyBinding;
import us.kenny.modules.Ev0lModule;
import us.kenny.modules.ModuleManager;
import us.kenny.modules.settings.BooleanModuleSetting;
import us.kenny.modules.settings.ModuleSetting;
import us.kenny.modules.settings.MultiSelectModuleSetting;
import us.kenny.modules.settings.NumberModuleSetting;
import us.kenny.modules.settings.TextModuleSetting;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * A minimal local-only HTTP server that exposes every registered module and
 * setting (see {@link ModuleManager}) as JSON, plus a single static HTML
 * page that renders them as a control panel, so the mod can be configured
 * from a browser instead of typing {@code ?config} commands into chat.
 * <p>
 * Bound to the loopback interface only (127.0.0.1), so it is never reachable
 * from outside the machine running Minecraft, and started once the same
 * settings the page will display are already populated (see the call site
 * in {@code OptionsMixin}, right after {@code ModuleManager.init()} and
 * {@code ConfigManager.loadConfigFile()}).
 */
public final class WebConfigServer {
    private static final int PORT = 28273;
    private static final Gson GSON = new Gson();

    private static HttpServer server;

    private WebConfigServer() {
    }

    public static synchronized void start() {
        if (server != null) {
            return;
        }
        try {
            server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), PORT), 0);
            server.createContext("/", WebConfigServer::handleIndex);
            server.createContext("/api/config", WebConfigServer::handleApi);
            server.createContext("/api/keybinds", WebConfigServer::handleKeybindsApi);
            server.setExecutor(Executors.newSingleThreadExecutor(runnable -> {
                Thread thread = new Thread(runnable, "ev0l-web-config");
                thread.setDaemon(true);
                return thread;
            }));
            server.start();
            MultiKeyBindingClient.LOGGER.info("ev0l config UI available at http://localhost:{}/", PORT);
        } catch (IOException e) {
            MultiKeyBindingClient.LOGGER.error("Failed to start web config server", e);
            server = null;
        }
    }

    // ---------------------------------------------------------------- index

    private static void handleIndex(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }
        byte[] body = IndexPage.HTML.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
        exchange.getResponseHeaders().add("Cache-Control", "no-store, must-revalidate");
        exchange.getResponseHeaders().add("Pragma", "no-cache");
        exchange.sendResponseHeaders(200, body.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(body);
        }
    }

    // ------------------------------------------------------------------ api

    private static void handleApi(HttpExchange exchange) throws IOException {
        try {
            String method = exchange.getRequestMethod();
            if ("GET".equalsIgnoreCase(method)) {
                sendJson(exchange, 200, buildConfigJson());
            } else if ("POST".equalsIgnoreCase(method)) {
                handlePost(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        } catch (Exception e) {
            MultiKeyBindingClient.LOGGER.error("Web config request failed", e);
            sendJson(exchange, 400, errorJson(describeError(e)));
        }
    }

    private static void handlePost(HttpExchange exchange) throws IOException {
        JsonObject request;
        try (InputStream in = exchange.getRequestBody()) {
            request = GSON.fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), JsonObject.class);
        }
        if (request == null || !request.has("module")) {
            sendJson(exchange, 400, errorJson("Missing 'module'"));
            return;
        }

        String moduleName = request.get("module").getAsString();
        Ev0lModule module = ModuleManager.get(moduleName);
        if (module == null) {
            sendJson(exchange, 404, errorJson("Unknown module: " + moduleName));
            return;
        }

        ModuleSetting setting = null;
        if (request.has("setting")) {
            setting = module.getSetting(request.get("setting").getAsString());
            if (setting == null) {
                sendJson(exchange, 404, errorJson("Unknown setting: " + request.get("setting").getAsString()));
                return;
            }
        }

        final ModuleSetting finalSetting = setting;
        boolean applied = runOnClientThread(() -> {
            if (request.has("enabled")) {
                module.setEnabled(request.get("enabled").getAsBoolean());
            }
            if (finalSetting != null && request.has("value")) {
                applyValue(finalSetting, request.get("value"));
            }
            ConfigManager.saveConfigFile();
        });

        if (!applied) {
            sendJson(exchange, 504, errorJson("Timed out applying change on the client thread"));
            return;
        }

        sendJson(exchange, 200, buildConfigJson());
    }

    /**
     * Apply a JSON value to a setting via its concrete type rather than
     * {@link ModuleSetting#setFromChatArg}, so booleans/numbers round-trip
     * exactly and an empty text value just works rather than needing the
     * "none"/"clear" keyword {@code setFromChatArg} requires to express an
     * empty string in chat's whitespace-split arguments.
     */
    private static void applyValue(ModuleSetting setting, JsonElement value) {
        if (setting instanceof BooleanModuleSetting bool) {
            bool.set(value.getAsBoolean());
        } else if (setting instanceof NumberModuleSetting number) {
            number.set(value.getAsDouble());
        } else if (setting instanceof TextModuleSetting text) {
            text.set(value.getAsString());
        } else if (setting instanceof MultiSelectModuleSetting multiSelect) {
            java.util.List<String> selected = new java.util.ArrayList<>();
            for (JsonElement entry : value.getAsJsonArray()) {
                selected.add(entry.getAsString());
            }
            multiSelect.set(selected);
        } else {
            setting.setFromChatArg(value.getAsString());
        }
    }

    /**
     * Settings mutate live game state (e.g. chat background opacity reaches
     * into vanilla's {@code Options}), and nothing here is synchronized
     * against the render/game thread, so changes are applied there rather
     * than directly from this handler's HTTP worker thread. Bounded with a
     * timeout so a stalled client thread can't hang an HTTP request
     * forever; the caller falls back to reporting the timeout as an error.
     */
    private static boolean runOnClientThread(Runnable task) {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            task.run();
            return true;
        }
        try {
            client.submit(task).get(2, TimeUnit.SECONDS);
            return true;
        } catch (Exception e) {
            MultiKeyBindingClient.LOGGER.error("Failed to apply web config change", e);
            return false;
        }
    }

    // ------------------------------------------------------------ keybinds

    /**
     * Mirrors {@link #handleApi}, but for vanilla key mappings + the custom
     * multi-bindings layered on top of them (see {@link MultiKeyBindingManager}).
     * This is the only place those multi-bindings can be added/removed/rebound
     * now; the vanilla Controls screen no longer injects its own UI for it
     * (see {@code KeyBindsListMixin}), so this page is the single source of
     * truth for configuring them.
     */
    private static void handleKeybindsApi(HttpExchange exchange) throws IOException {
        try {
            String method = exchange.getRequestMethod();
            if ("GET".equalsIgnoreCase(method)) {
                sendJson(exchange, 200, buildKeybindsJson());
            } else if ("POST".equalsIgnoreCase(method)) {
                handleKeybindsPost(exchange);
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        } catch (Exception e) {
            MultiKeyBindingClient.LOGGER.error("Web keybinds request failed", e);
            sendJson(exchange, 400, errorJson(describeError(e)));
        }
    }

    private static void handleKeybindsPost(HttpExchange exchange) throws IOException {
        JsonObject request;
        try (InputStream in = exchange.getRequestBody()) {
            request = GSON.fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), JsonObject.class);
        }
        if (request == null) {
            sendJson(exchange, 400, errorJson("Missing request body"));
            return;
        }

        boolean applied = runOnClientThread(() -> {
            if (request.has("removeId")) {
                UUID id = UUID.fromString(request.get("removeId").getAsString());
                MultiKeyBindingManager.removeKeyBinding(MultiKeyBindingManager.getKeyBinding(id));
            } else if (request.has("rebindId") && request.has("key")) {
                UUID id = UUID.fromString(request.get("rebindId").getAsString());
                MultiKeyBinding binding = MultiKeyBindingManager.getKeyBinding(id);
                if (binding != null) {
                    MultiKeyBindingManager.setKeyBinding(binding, InputConstants.getKey(request.get("key").getAsString()));
                }
            } else if (request.has("action") && request.has("key")) {
                String action = request.get("action").getAsString();
                KeyMapping.Category category = findCategory(action);
                InputConstants.Key key = InputConstants.getKey(request.get("key").getAsString());
                MultiKeyBindingManager.addKeyBinding(action, category, key);
            }
            ConfigManager.saveConfigFile();
        });

        if (!applied) {
            sendJson(exchange, 504, errorJson("Timed out applying change on the client thread"));
            return;
        }
        sendJson(exchange, 200, buildKeybindsJson());
    }

    private static KeyMapping.Category findCategory(String action) {
        Options options = MultiKeyBindingManager.getGameOptions();
        if (options == null) {
            return null;
        }
        for (KeyMapping km : options.keyMappings) {
            if (km.getName().equals(action)) {
                return km.getCategory();
            }
        }
        return null;
    }

    private static JsonObject buildKeybindsJson() {
        JsonObject root = new JsonObject();
        JsonArray categories = new JsonArray();
        Options options = MultiKeyBindingManager.getGameOptions();
        if (options != null) {
            // Group by category preserving first-seen order (vanilla's keyMappings array
            // is already grouped by category, so insertion order gives vanilla category order).
            java.util.LinkedHashMap<KeyMapping.Category, java.util.List<KeyMapping>> byCategory =
                    new java.util.LinkedHashMap<>();
            for (KeyMapping km : options.keyMappings) {
                byCategory.computeIfAbsent(km.getCategory(), k -> new java.util.ArrayList<>()).add(km);
            }

            for (java.util.Map.Entry<KeyMapping.Category, java.util.List<KeyMapping>> catEntry : byCategory.entrySet()) {
                KeyMapping.Category cat = catEntry.getKey();
                java.util.List<KeyMapping> kms = catEntry.getValue();

                // Sort within category by display name
                kms.sort(Comparator.comparing(km -> Component.translatable(km.getName()).getString()));

                JsonObject catObj = new JsonObject();
                catObj.addProperty("category", cat.label().getString());

                JsonArray keybinds = new JsonArray();
                for (KeyMapping km : kms) {
                    JsonObject entry = new JsonObject();
                    entry.addProperty("action", km.getName());
                    entry.addProperty("displayName", Component.translatable(km.getName()).getString());

                    InputConstants.Key vanillaKey = ((us.kenny.mixin.KeyMappingAccessor) km).getBoundKey();
                    entry.addProperty("vanillaKeyName", vanillaKey.getDisplayName().getString());

                    JsonArray bindings = new JsonArray();
                    for (MultiKeyBinding mkb : MultiKeyBindingManager.getKeyBindings(km.getName())) {
                        JsonObject b = new JsonObject();
                        b.addProperty("id", mkb.getId().toString());
                        b.addProperty("key", mkb.getKey().getName());
                        b.addProperty("keyName", mkb.getKey().getDisplayName().getString());
                        bindings.add(b);
                    }
                    entry.add("bindings", bindings);
                    keybinds.add(entry);
                }
                catObj.add("keybinds", keybinds);
                categories.add(catObj);
            }
        }
        root.add("categories", categories);
        return root;
    }

    // --------------------------------------------------------- json shapes

    private static JsonObject buildConfigJson() {
        JsonObject root = new JsonObject();
        JsonArray modules = new JsonArray();
        for (Ev0lModule module : ModuleManager.getAll()) {
            JsonObject moduleJson = new JsonObject();
            moduleJson.addProperty("name", module.getName());
            moduleJson.addProperty("description", module.getDescription());
            moduleJson.addProperty("enabled", module.isEnabled());

            JsonArray settingsJson = new JsonArray();
            for (ModuleSetting setting : module.getSettings()) {
                settingsJson.add(describeSetting(setting));
            }
            moduleJson.add("settings", settingsJson);
            modules.add(moduleJson);
        }
        root.add("modules", modules);
        return root;
    }

    private static JsonObject describeSetting(ModuleSetting setting) {
        JsonObject json = new JsonObject();
        json.addProperty("name", setting.getName());
        json.addProperty("description", setting.getDescription());
        if (setting instanceof BooleanModuleSetting bool) {
            json.addProperty("type", "boolean");
            json.addProperty("value", bool.get());
        } else if (setting instanceof NumberModuleSetting number) {
            json.addProperty("type", "number");
            json.addProperty("value", number.get());
            json.addProperty("min", number.getMin());
            json.addProperty("max", number.getMax());
        } else if (setting instanceof TextModuleSetting text) {
            json.addProperty("type", "text");
            json.addProperty("value", text.get());
        } else if (setting instanceof MultiSelectModuleSetting multiSelect) {
            json.addProperty("type", "multiselect");
            JsonArray options = new JsonArray();
            for (String option : multiSelect.getOptions()) {
                options.add(option);
            }
            json.add("options", options);
            JsonArray value = new JsonArray();
            for (String selected : multiSelect.get()) {
                value.add(selected);
            }
            json.add("value", value);
        } else {
            // Defensive fallback for any future ModuleSetting subclass.
            json.addProperty("type", "text");
            json.addProperty("value", setting.displayValue());
        }
        return json;
    }

    private static JsonObject errorJson(String message) {
        JsonObject error = new JsonObject();
        error.addProperty("error", message);
        return error;
    }

    private static String describeError(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private static void sendJson(HttpExchange exchange, int status, JsonObject json) throws IOException {
        byte[] body = GSON.toJson(json).getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, body.length);
        try (OutputStream out = exchange.getResponseBody()) {
            out.write(body);
        }
    }
}
