package us.kenny.commands.impl;

import java.util.Arrays;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

import us.kenny.commands.ChatUtil;
import us.kenny.commands.Ev0lCommand;
import us.kenny.modules.Ev0lModule;
import us.kenny.modules.ModuleManager;
import us.kenny.modules.settings.ModuleSetting;

/**
 * <pre>
 * ?config                          - list every module and whether it's enabled
 * ?config &lt;module&gt;                 - list that module's settings and current values
 * ?config &lt;module&gt; &lt;setting&gt;        - show one setting's current value
 * ?config &lt;module&gt; &lt;setting&gt; &lt;value&gt; - set one setting's value
 * </pre>
 */
public class ConfigCommand extends Ev0lCommand {
    public ConfigCommand() {
        super("config", "Views or changes module settings", "?config [module] [setting] [value]");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            listModules();
            return;
        }

        Ev0lModule module = ModuleManager.get(args[0]);
        if (module == null) {
            ChatUtil.error("Unknown module '" + args[0] + "'. Try ?config to list modules.");
            return;
        }

        if (args.length == 1) {
            listSettings(module);
            return;
        }

        ModuleSetting setting = module.getSetting(args[1]);
        if (setting == null) {
            ChatUtil.error("Unknown setting '" + args[1] + "' for module '" + module.getName() + "'.");
            return;
        }

        if (args.length == 2) {
            ChatUtil.send(settingLine(setting));
            return;
        }

        String value = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        if (!setting.setFromChatArg(value)) {
            ChatUtil.error("Couldn't set '" + setting.getName() + "' to '" + value + "'.");
            return;
        }
        ChatUtil.success(module.getName() + "." + setting.getName() + " = " + setting.displayValue());
    }

    private void listModules() {
        ChatUtil.send(Component.literal("Modules:").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        for (Ev0lModule module : ModuleManager.getAll()) {
            ChatUtil.send(Component.literal(module.getName())
                    .withStyle(module.isEnabled() ? ChatFormatting.GREEN : ChatFormatting.RED)
                    .append(Component.literal(" - ").withStyle(ChatFormatting.GRAY))
                    .append(Component.literal(module.getDescription()).withStyle(ChatFormatting.WHITE)));
        }
    }

    private void listSettings(Ev0lModule module) {
        ChatUtil.send(Component.literal(module.getName()).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)
                .append(Component.literal(" [" + (module.isEnabled() ? "enabled" : "disabled") + "]")
                        .withStyle(module.isEnabled() ? ChatFormatting.GREEN : ChatFormatting.RED)));
        if (module.getSettings().isEmpty()) {
            ChatUtil.send(Component.literal("  (no settings)").withStyle(ChatFormatting.GRAY));
            return;
        }
        for (ModuleSetting setting : module.getSettings()) {
            ChatUtil.send(settingLine(setting));
        }
    }

    private Component settingLine(ModuleSetting setting) {
        return Component.literal("  " + setting.getName()).withStyle(ChatFormatting.YELLOW)
                .append(Component.literal(" = ").withStyle(ChatFormatting.GRAY))
                .append(Component.literal(setting.displayValue()).withStyle(ChatFormatting.WHITE));
    }
}
