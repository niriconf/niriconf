package us.kenny.commands.impl;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

import us.kenny.commands.ChatUtil;
import us.kenny.commands.CommandManager;
import us.kenny.commands.Ev0lCommand;

public class HelpCommand extends Ev0lCommand {
    public HelpCommand() {
        super("help", "Lists every chat command", "?help");
    }

    @Override
    public void execute(String[] args) {
        ChatUtil.send(Component.literal("ev0l commands:").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        for (Ev0lCommand command : CommandManager.getAll()) {
            ChatUtil.send(Component.literal(command.getUsage()).withStyle(ChatFormatting.YELLOW)
                    .append(Component.literal(" - ").withStyle(ChatFormatting.GRAY))
                    .append(Component.literal(command.getDescription()).withStyle(ChatFormatting.WHITE)));
        }
    }
}
