package us.kenny.commands.impl;

import us.kenny.commands.ChatUtil;
import us.kenny.commands.Ev0lCommand;
import us.kenny.modules.Ev0lModule;
import us.kenny.modules.ModuleManager;
import us.kenny.modules.settings.BooleanModuleSetting;

/**
 * {@code ?set <module> <true|false>} - enables or disables a whole module.
 * For per-setting values, see {@code ?config}.
 */
public class SetCommand extends Ev0lCommand {
    public SetCommand() {
        super("set", "Enables or disables a module", "?set <module> <true|false>");
    }

    @Override
    public void execute(String[] args) {
        if (args.length != 2) {
            ChatUtil.error("Usage: " + getUsage());
            return;
        }

        Ev0lModule module = ModuleManager.get(args[0]);
        if (module == null) {
            ChatUtil.error("Unknown module '" + args[0] + "'. Try ?config to list modules.");
            return;
        }

        Boolean state = BooleanModuleSetting.parse(args[1]);
        if (state == null) {
            ChatUtil.error("Expected true/false, got '" + args[1] + "'.");
            return;
        }

        module.setEnabled(state);
        ChatUtil.success(module.getName() + " " + (state ? "enabled" : "disabled"));
    }
}
