package us.kenny.commands;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import us.kenny.commands.impl.ConfigCommand;
import us.kenny.commands.impl.HelpCommand;
import us.kenny.commands.impl.SetCommand;

public final class CommandManager {
    public static final String PREFIX = "?";

    // LinkedHashMap so ?help lists commands in registration order.
    private static final Map<String, Ev0lCommand> COMMANDS = new LinkedHashMap<>();
    private static boolean initialised = false;

    private CommandManager() {
    }

    public static void init() {
        if (initialised) {
            return;
        }
        initialised = true;
        register(new HelpCommand());
        register(new SetCommand());
        register(new ConfigCommand());
    }

    private static void register(Ev0lCommand command) {
        COMMANDS.put(command.getName().toLowerCase(), command);
    }

    public static Iterable<Ev0lCommand> getAll() {
        return COMMANDS.values();
    }

    public static Ev0lCommand get(String name) {
        return name == null ? null : COMMANDS.get(name.toLowerCase());
    }

    /**
     * Dispatch chat text that followed the '?' prefix (prefix already
     * stripped). Called from {@code ChatSendMixin}.
     */
    public static void dispatch(String raw) {
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            ChatUtil.error("Type ?help for a list of commands.");
            return;
        }

        String[] parts = trimmed.split("\\s+");
        String name = parts[0];
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);

        Ev0lCommand command = get(name);
        if (command == null) {
            ChatUtil.error("Unknown command '" + name + "'. Try ?help.");
            return;
        }

        try {
            command.execute(args);
        } catch (Exception e) {
            ChatUtil.error("Command failed: " + e.getMessage());
        }
    }
}
