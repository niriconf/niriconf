package us.kenny.commands;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Sends chat feedback that's only visible locally - never goes to the server.
 * Mirrors Pulse Client's ChatUtil pattern.
 */
public final class ChatUtil {
    private static final String TAG = "[ev0l] ";

    private ChatUtil() {
    }

    public static void info(String message) {
        send(tag().append(Component.literal(message).withStyle(ChatFormatting.WHITE)));
    }

    public static void success(String message) {
        send(tag().append(Component.literal(message).withStyle(ChatFormatting.GREEN)));
    }

    public static void error(String message) {
        send(tag().append(Component.literal(message).withStyle(ChatFormatting.RED)));
    }

    public static void send(Component component) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui != null) {
            mc.gui.getChat().addMessage(component);
        }
    }

    private static MutableComponent tag() {
        return Component.literal(TAG).withStyle(ChatFormatting.AQUA);
    }
}
