package us.kenny.commands;

/**
 * A command dispatched from chat text following the '?' prefix (see
 * {@link CommandManager}). Mirrors Pulse Client's ClientCommand pattern.
 */
public abstract class Ev0lCommand {
    private final String name;
    private final String description;
    private final String usage;

    protected Ev0lCommand(String name, String description, String usage) {
        this.name = name;
        this.description = description;
        this.usage = usage;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getUsage() {
        return usage;
    }

    /** args does not include the command name itself. */
    public abstract void execute(String[] args);
}
