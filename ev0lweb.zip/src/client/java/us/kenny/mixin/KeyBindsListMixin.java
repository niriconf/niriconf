package us.kenny.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractSelectionList;
import net.minecraft.client.gui.screens.options.controls.KeyBindsList;

@Mixin(KeyBindsList.class)
public abstract class KeyBindsListMixin extends AbstractSelectionList<KeyBindsList.Entry> {

    public KeyBindsListMixin(Minecraft client, int width, int height, int y, int itemHeight) {
        super(client, width, height, y, itemHeight);
    }

    /**
     * Previously inserted a {@link MultiKeyBindingEntry} into the vanilla
     * Controls screen for every custom binding under each vanilla key. That
     * configuration now lives entirely in the web UI (see
     * {@code WebConfigServer}/{@code IndexPage}), so this no longer inserts
     * anything; the vanilla list is left untouched.
     */
    @WrapOperation(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/options/controls/KeyBindsList;addEntry(Lnet/minecraft/client/gui/components/AbstractSelectionList$Entry;)I", ordinal = 1))
    private int onAddEntry(KeyBindsList instance,
            AbstractSelectionList.Entry<KeyBindsList.Entry> entry,
            Operation<Integer> original) {
        return original.call(instance, entry);
    }

    /**
     * Previously appended a primary entry (plus its sub-bindings) for each
     * "multi.toggle.key.*" action. Toggle bindings are now configured from
     * the web UI instead, so this is a no-op.
     */
    @Inject(method = "<init>", at = @At("RETURN"))
    private void addToggleEntries(CallbackInfo ci) {
    }
}