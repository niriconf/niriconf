package us.kenny.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.multiplayer.ClientPacketListener;

import us.kenny.commands.CommandManager;
import us.kenny.modules.impl.ChatModule;

/**
 * Intercepts outgoing chat before it's signed and sent to the server:
 * messages starting with '?' are routed to {@link CommandManager} and never
 * sent, everything else is passed through {@link ChatModule#style} if the
 * chat module is enabled.
 * <p>
 * Styling is applied by recursively calling {@code sendChat} with the styled
 * text (guarded by {@code STYLING_IN_PROGRESS} to avoid infinite recursion)
 * rather than rewriting the packet after signing, so the styled text is what
 * actually gets signed for servers enforcing secure chat.
 */
@Mixin(ClientPacketListener.class)
public class ChatSendMixin {
    private static final ThreadLocal<Boolean> STYLING_IN_PROGRESS = ThreadLocal.withInitial(() -> false);

    @Inject(method = "sendChat", at = @At("HEAD"), cancellable = true)
    private void onSendChat(String message, CallbackInfo ci) {
        if (STYLING_IN_PROGRESS.get()) {
            return;
        }

        if (message.startsWith(CommandManager.PREFIX)) {
            ci.cancel();
            CommandManager.dispatch(message.substring(CommandManager.PREFIX.length()));
            return;
        }

        if (!ChatModule.INSTANCE.isEnabled()) {
            return;
        }

        String styled = ChatModule.INSTANCE.style(message);
        if (styled.equals(message)) {
            return;
        }

        ci.cancel();
        STYLING_IN_PROGRESS.set(true);
        try {
            ((ClientPacketListener) (Object) this).sendChat(styled);
        } finally {
            STYLING_IN_PROGRESS.set(false);
        }
    }
}
