package us.kenny.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;

import us.kenny.modules.impl.ChatModule;

/**
 * Applies ChatModule's timestamp and font settings to incoming chat lines.
 * {@code require = 0} so a method-descriptor mismatch against a different
 * Minecraft version only disables this one feature (logged) instead of
 * crashing the whole mixin environment - this is the highest-risk new mixin
 * in this patch since it targets an overload by exact descriptor; double
 * check it against your local client mappings if timestamps/font don't show
 * up.
 */
@Mixin(ChatComponent.class)
public class ChatHudMixin {

    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("HEAD"),
            argsOnly = true,
            require = 0)
    private Component onAddMessage(Component message) {
        // 1. Prepend timestamp (already applies toFancy to the stamp string when fancyChat is on).
        Component withTimestamp = ChatModule.INSTANCE.withTimestamp(message);
        // 2. Apply small-caps to every literal node (name, message body, punctuation).
        Component withFancy = ChatModule.INSTANCE.withFancyChat(withTimestamp);
        // 3. Wrap in the configured font so the whole line renders consistently.
        return ChatModule.INSTANCE.withFont(withFancy);
    }
}
