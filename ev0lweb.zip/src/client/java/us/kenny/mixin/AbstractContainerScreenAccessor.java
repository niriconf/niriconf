package us.kenny.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {

    @Invoker("getHoveredSlot")
    Slot mkb$getHoveredSlot(double mouseX, double mouseY);

    @Invoker("slotClicked")
    void mkb$slotClicked(Slot slot, int slotId, int mouseButton, ClickType clickType);

    @Accessor("isQuickCrafting")
    boolean mkb$getIsQuickCrafting();

    @Accessor("isQuickCrafting")
    void mkb$setIsQuickCrafting(boolean value);

    @Accessor("skipNextRelease")
    void mkb$setSkipNextRelease(boolean value);
}
