package us.kenny.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import us.kenny.modules.impl.AutoSprintModule;

@Mixin(LocalPlayer.class)
public class LocalPlayerMixin {

    @Inject(method = "aiStep", at = @At("HEAD"))
    private void onAiStep(CallbackInfo ci) {
        if (!AutoSprintModule.INSTANCE.isEnabled()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.options == null) return;
        if (mc.player == null) return;
        if (mc.screen != null) return;

        LocalPlayer player = (LocalPlayer) (Object) this;

        // Force sprint active unless sneaking or underwater
        if (!player.isShiftKeyDown() && !player.isUnderWater()) {
            ((KeyMappingAccessor) mc.options.keySprint).setIsDown(true);
        }
    }
}
