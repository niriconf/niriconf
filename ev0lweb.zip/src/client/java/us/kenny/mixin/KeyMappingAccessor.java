package us.kenny.mixin;

import java.util.List;
import java.util.Map;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(KeyMapping.class)
public interface KeyMappingAccessor {
    @Accessor("key")
    InputConstants.Key getBoundKey();

    @Accessor("isDown")
    boolean getIsDown();

    @Accessor("isDown")
    void setIsDown(boolean isDown);

    @Accessor("MAP")
    static Map<InputConstants.Key, List<KeyMapping>> getMap() {
        throw new AssertionError();
    }
}
