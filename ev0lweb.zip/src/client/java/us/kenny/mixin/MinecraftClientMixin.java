package us.kenny.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import us.kenny.modules.impl.AimModule;

/**
 * Drives {@link AimModule}'s per-frame rotation step. Hooking the client's
 * own render method (called once per rendered frame from the main loop)
 * rather than a tick event keeps the turn rate smooth at whatever frame
 * rate the game is actually running at, instead of being chunked into the
 * fixed 20Hz tick rate.
 */
@Mixin(Minecraft.class)
public class MinecraftClientMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderFrame(boolean tick, CallbackInfo ci) {
        AimModule.INSTANCE.onFrame();
    }
}
