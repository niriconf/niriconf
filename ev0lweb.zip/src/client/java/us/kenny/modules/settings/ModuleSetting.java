package us.kenny.modules.settings;

import com.google.gson.JsonElement;

/**
 * A single configurable value belonging to an {@link us.kenny.modules.Ev0lModule}.
 * Exposes a uniform string interface so the chat command system ({@code ?config
 * <module> <setting> <value>}) can read and write any setting type without
 * knowing its concrete class, plus JSON (de)serialization for ConfigManager.
 */
public abstract class ModuleSetting {
    private final String name;
    private final String description;
    private Runnable onChange;

    protected ModuleSetting(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Register a callback fired whenever this setting's value changes, whether
     * from a chat command or from config load. Used by settings that need to
     * push their value out to a live vanilla option (e.g. chat background
     * opacity).
     */
    public void onChange(Runnable callback) {
        this.onChange = callback;
    }

    protected void notifyChanged() {
        if (onChange != null) {
            onChange.run();
        }
    }

    /** Human-readable current value, shown by {@code ?config}. */
    public abstract String displayValue();

    /**
     * Attempt to parse and apply a value typed in chat (e.g. after
     * {@code ?config <module> <setting> }). Returns false if the raw text
     * couldn't be parsed as this setting's type, leaving the value unchanged.
     */
    public abstract boolean setFromChatArg(String raw);

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement element);
}
