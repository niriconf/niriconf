package us.kenny.modules.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class TextModuleSetting extends ModuleSetting {
    private String value;

    public TextModuleSetting(String name, String description, String defaultValue) {
        super(name, description);
        this.value = defaultValue;
    }

    public String get() {
        return value;
    }

    public void set(String value) {
        if (this.value.equals(value)) {
            return;
        }
        this.value = value;
        notifyChanged();
    }

    @Override
    public String displayValue() {
        return value.isEmpty() ? "\"\"" : value;
    }

    @Override
    public boolean setFromChatArg(String raw) {
        // Chat input is whitespace-split, so there's no way to type a literal
        // empty string as an argument - recognize a few clear keywords instead.
        // "" matches what displayValue() shows for an already-empty setting.
        if (raw.equalsIgnoreCase("none") || raw.equalsIgnoreCase("clear") || raw.equals("\"\"")) {
            set("");
        } else {
            set(raw);
        }
        return true;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        set(element.getAsString());
    }
}
