package us.kenny.modules.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class BooleanModuleSetting extends ModuleSetting {
    private boolean value;

    public BooleanModuleSetting(String name, String description, boolean defaultValue) {
        super(name, description);
        this.value = defaultValue;
    }

    public boolean get() {
        return value;
    }

    public void set(boolean value) {
        if (this.value == value) {
            return;
        }
        this.value = value;
        notifyChanged();
    }

    @Override
    public String displayValue() {
        return Boolean.toString(value);
    }

    @Override
    public boolean setFromChatArg(String raw) {
        Boolean parsed = parse(raw);
        if (parsed == null) {
            return false;
        }
        set(parsed);
        return true;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        set(element.getAsBoolean());
    }

    /**
     * Lenient boolean parsing shared with module enable/disable ({@code ?set}).
     */
    public static Boolean parse(String raw) {
        if (raw == null) {
            return null;
        }
        return switch (raw.toLowerCase()) {
            case "true", "on", "enable", "enabled", "yes", "1" -> Boolean.TRUE;
            case "false", "off", "disable", "disabled", "no", "0" -> Boolean.FALSE;
            default -> null;
        };
    }
}
