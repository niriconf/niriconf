package us.kenny.modules.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * A setting whose value is any number of choices out of a fixed list of
 * options (e.g. "which entity types to target"), rendered in the web UI as
 * a checkbox dropdown rather than a single {@code <select>}.
 */
public class MultiSelectModuleSetting extends ModuleSetting {
    private final List<String> options;
    private final Set<String> value = new LinkedHashSet<>();

    public MultiSelectModuleSetting(String name, String description, List<String> options,
            Collection<String> defaultValue) {
        super(name, description);
        this.options = List.copyOf(options);
        for (String v : defaultValue) {
            if (this.options.contains(v)) {
                this.value.add(v);
            }
        }
    }

    /** The full list of selectable options, in display order. */
    public List<String> getOptions() {
        return options;
    }

    /** Currently-selected options, in selection order. */
    public Set<String> get() {
        return Collections.unmodifiableSet(value);
    }

    public boolean contains(String option) {
        return value.contains(option);
    }

    /** Replace the selection. Entries not in {@link #getOptions()} are silently dropped. */
    public void set(Collection<String> newValue) {
        Set<String> sanitized = new LinkedHashSet<>();
        for (String v : newValue) {
            if (options.contains(v)) {
                sanitized.add(v);
            }
        }
        if (value.equals(sanitized)) {
            return;
        }
        value.clear();
        value.addAll(sanitized);
        notifyChanged();
    }

    @Override
    public String displayValue() {
        return value.isEmpty() ? "none" : String.join(", ", value);
    }

    /**
     * Chat form is a comma-separated list of option values (no spaces between
     * entries needed since commas are the delimiter), plus the keywords
     * "none" and "all" for convenience, e.g. {@code ?config aim targets
     * minecraft:zombie,minecraft:skeleton}.
     */
    @Override
    public boolean setFromChatArg(String raw) {
        if (raw.equalsIgnoreCase("none") || raw.equals("\"\"")) {
            set(List.of());
            return true;
        }
        if (raw.equalsIgnoreCase("all")) {
            set(options);
            return true;
        }
        List<String> parsed = Arrays.stream(raw.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
        set(parsed);
        return true;
    }

    @Override
    public JsonElement toJson() {
        JsonArray array = new JsonArray();
        for (String v : value) {
            array.add(v);
        }
        return array;
    }

    @Override
    public void fromJson(JsonElement element) {
        List<String> parsed = new ArrayList<>();
        if (element.isJsonArray()) {
            for (JsonElement entry : element.getAsJsonArray()) {
                parsed.add(entry.getAsString());
            }
        }
        set(parsed);
    }
}
