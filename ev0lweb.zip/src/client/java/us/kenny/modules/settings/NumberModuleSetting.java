package us.kenny.modules.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberModuleSetting extends ModuleSetting {
    private final double min;
    private final double max;
    private double value;

    public NumberModuleSetting(String name, String description, double defaultValue, double min, double max) {
        super(name, description);
        this.min = min;
        this.max = max;
        this.value = clamp(defaultValue);
    }

    public double get() {
        return value;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public void set(double value) {
        double clamped = clamp(value);
        if (this.value == clamped) {
            return;
        }
        this.value = clamped;
        notifyChanged();
    }

    private double clamp(double v) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public String displayValue() {
        // Drop the decimal point for whole numbers so "90" doesn't print as "90.0".
        return value == Math.floor(value) ? String.valueOf((long) value) : String.valueOf(value);
    }

    @Override
    public boolean setFromChatArg(String raw) {
        try {
            set(Double.parseDouble(raw));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        set(element.getAsDouble());
    }
}
