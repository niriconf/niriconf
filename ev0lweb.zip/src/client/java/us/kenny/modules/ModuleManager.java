package us.kenny.modules;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import us.kenny.modules.impl.AimModule;
import us.kenny.modules.impl.AutoSprintModule;
import us.kenny.modules.impl.ChatModule;
import us.kenny.modules.impl.MultiBindModule;
import us.kenny.modules.impl.ShiftDragModule;

public final class ModuleManager {
    // LinkedHashMap so ?config's module listing has a stable, predictable order.
    private static final Map<String, Ev0lModule> MODULES = new LinkedHashMap<>();
    private static boolean initialised = false;

    private ModuleManager() {
    }

    /**
     * Register every module. Must run before {@code ConfigManager.loadConfigFile()}
     * so there's something for the saved config to apply onto.
     */
    public static void init() {
        if (initialised) {
            return;
        }
        initialised = true;
        register(MultiBindModule.INSTANCE);
        register(AutoSprintModule.INSTANCE);
        register(ShiftDragModule.INSTANCE);
        register(ChatModule.INSTANCE);
        register(AimModule.INSTANCE);
    }

    private static void register(Ev0lModule module) {
        MODULES.put(module.getName().toLowerCase(), module);
    }

    /** Case-insensitive module lookup, used by {@code ?set} / {@code ?config}. */
    public static Ev0lModule get(String name) {
        return name == null ? null : MODULES.get(name.toLowerCase());
    }

    public static Collection<Ev0lModule> getAll() {
        return MODULES.values();
    }
}
