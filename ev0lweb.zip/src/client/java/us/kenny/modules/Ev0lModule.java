package us.kenny.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import us.kenny.modules.settings.ModuleSetting;

/**
 * A toggleable feature of the mod that can be enabled/disabled and configured
 * entirely through chat (see {@code us.kenny.commands}), in addition to
 * whatever code path it wraps. Subclasses are singletons (one {@code INSTANCE}
 * per module) registered with {@link ModuleManager}.
 */
public abstract class Ev0lModule {
    private final String name;
    private final String description;
    private final List<ModuleSetting> settings = new ArrayList<>();
    private boolean enabled;

    protected Ev0lModule(String name, String description, boolean defaultEnabled) {
        this.name = name;
        this.description = description;
        this.enabled = defaultEnabled;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    /** Called once when the module transitions from disabled to enabled. */
    protected void onEnable() {
    }

    /** Called once when the module transitions from enabled to disabled. */
    protected void onDisable() {
    }

    protected void registerSetting(ModuleSetting setting) {
        settings.add(setting);
    }

    public List<ModuleSetting> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    /** Case-insensitive setting lookup, used by {@code ?config}. */
    public ModuleSetting getSetting(String settingName) {
        for (ModuleSetting setting : settings) {
            if (setting.getName().equalsIgnoreCase(settingName)) {
                return setting;
            }
        }
        return null;
    }
}
