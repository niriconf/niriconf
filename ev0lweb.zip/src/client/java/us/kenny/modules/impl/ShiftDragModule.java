package us.kenny.modules.impl;

import us.kenny.modules.Ev0lModule;

/**
 * Gates {@code ShiftDragManager}'s shift+left-click-drag quick-move behavior.
 * Enabled by default to match its previous always-on behavior.
 */
public final class ShiftDragModule extends Ev0lModule {
    public static final ShiftDragModule INSTANCE = new ShiftDragModule();

    private ShiftDragModule() {
        super("shiftdrag", "Shift+left-click-drag quick-moves items across inventory slots", true);
    }
}
