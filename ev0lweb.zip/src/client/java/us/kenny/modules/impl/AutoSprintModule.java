package us.kenny.modules.impl;

import us.kenny.modules.Ev0lModule;

/**
 * Gates the forced-sprint logic in {@code LocalPlayerMixin}. Enabled by
 * default since that mixin previously ran unconditionally - this just makes
 * the existing behavior toggleable from chat ({@code ?set autosprint false}).
 */
public final class AutoSprintModule extends Ev0lModule {
    public static final AutoSprintModule INSTANCE = new AutoSprintModule();

    private AutoSprintModule() {
        super("autosprint", "Always sprint forward unless sneaking or underwater", true);
    }
}
