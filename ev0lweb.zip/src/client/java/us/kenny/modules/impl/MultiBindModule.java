package us.kenny.modules.impl;

import us.kenny.modules.Ev0lModule;

/**
 * Master switch for the extra multi-keybinding dispatch added by
 * {@code KeyMappingMixin} (secondary key activation, toggle-mode flipping,
 * sticky-toggle restore/reset on screen open/close). Enabled by default.
 *
 * Scope note: disabling this pauses *dispatch* of extra bindings/toggle
 * behavior so vanilla's own input handling takes back over cleanly. It
 * intentionally leaves modifier-chord matching and the key-binds screen UI
 * untouched, since those affect how bindings are displayed/edited rather than
 * runtime gameplay, and reverting them fully isn't worth the risk of subtly
 * breaking the binds menu.
 */
public final class MultiBindModule extends Ev0lModule {
    public static final MultiBindModule INSTANCE = new MultiBindModule();

    private MultiBindModule() {
        super("multibind", "Extra multi-keybinding and sticky-toggle dispatch", true);
    }
}
