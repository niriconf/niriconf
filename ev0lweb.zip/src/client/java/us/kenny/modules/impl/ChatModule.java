package us.kenny.modules.impl;

import java.time.LocalTime;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Options;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.contents.PlainTextContents;
import net.minecraft.resources.Identifier;

import us.kenny.MultiKeyBindingManager;
import us.kenny.modules.Ev0lModule;
import us.kenny.modules.settings.BooleanModuleSetting;
import us.kenny.modules.settings.TextModuleSetting;

/**
 * Chat styling ported from Pulse Client's "Chat" module: a prefix/suffix
 * appended to every outgoing message, an optional small-caps "fancy chat"
 * transform, incoming-message timestamps, a no-background mode, and a font
 * swap using vanilla's own built-in chat fonts.
 * <p>
 * Pulse's "Animation" setting isn't included here - it depends on Pulse's
 * own render-tick animation framework, which doesn't exist in ev0l, so
 * there's nothing to wrap it around.
 */
public final class ChatModule extends Ev0lModule {
    public static final ChatModule INSTANCE = new ChatModule();

    private static final String LOWER = "abcdefghijklmnopqrstuvwxyz";
    // q, x, y have no standard Unicode small-caps glyph, so they pass through unchanged.
    private static final String SMALL_CAPS = "\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18q\u0280\ua731\u1d1b\u1d1c\u1d20\u1d21xy\u1d22";

    public final TextModuleSetting prefix =
            new TextModuleSetting("prefix", "Text prepended to every outgoing chat message", "");
    public final TextModuleSetting suffix =
            new TextModuleSetting("suffix", "Text appended to every outgoing chat message", "");
    public final BooleanModuleSetting fancyChat =
            new BooleanModuleSetting("fancychat", "Replaces letters with small caps (outgoing messages and incoming name/timestamp/body)", false);
    public final BooleanModuleSetting onlySuffix =
            new BooleanModuleSetting("onlysuffix", "Only apply the fancy-chat transform to the suffix", false);
    public final BooleanModuleSetting timestamps =
            new BooleanModuleSetting("timestamps", "Show a [HH:mm] timestamp on incoming chat lines", false);
    public final BooleanModuleSetting noBackground =
            new BooleanModuleSetting("nobackground", "Remove the chat background", false);
    public final TextModuleSetting font =
            new TextModuleSetting("font", "Chat font: default, uniform, alt, or a namespace:path resource location", "default");

    /** Vanilla's chat background opacity from before nobackground was applied, so it can be restored. */
    private Double savedBackgroundOpacity = null;

    private ChatModule() {
        super("chat", "Outgoing message styling and chat HUD tweaks", false);
        registerSetting(prefix);
        registerSetting(suffix);
        registerSetting(fancyChat);
        registerSetting(onlySuffix);
        registerSetting(timestamps);
        registerSetting(noBackground);
        registerSetting(font);

        noBackground.onChange(this::applyBackgroundOpacity);
    }

    @Override
    protected void onEnable() {
        applyBackgroundOpacity();
    }

    @Override
    protected void onDisable() {
        applyBackgroundOpacity();
    }

    /**
     * Apply prefix/suffix/fancy-chat styling to an outgoing message. Called
     * from {@code ChatSendMixin} before the message is sent to the server.
     */
    public String style(String message) {
        String pre = prefix.get();
        String suf = suffix.get();
        if (fancyChat.get()) {
            return onlySuffix.get() ? pre + message + toFancy(suf) : toFancy(pre + message + suf);
        }
        return pre + message + suf;
    }

    /**
     * Prepend a timestamp to an incoming chat line if enabled. Called from
     * {@code ChatHudMixin}.
     */
    public Component withTimestamp(Component message) {
        if (!isEnabled() || !timestamps.get()) {
            return message;
        }
        LocalTime now = LocalTime.now();
        String stamp = String.format(">>%02d:%02d ", now.getHour(), now.getMinute());
        // Apply fancy-chat to the timestamp text itself when fancyChat is enabled.
        if (fancyChat.get()) {
            stamp = toFancy(stamp);
        }
        return Component.literal(stamp).withStyle(ChatFormatting.GRAY).append(message);
    }

    /**
     * Recursively rewrite every PlainTextContents node in a component tree
     * through {@link #toFancy}, so the small-caps transform is applied to
     * the player name and message body on incoming chat lines (not just to
     * outgoing text).  Non-literal nodes (translations, scores, etc.) are
     * left intact; their sibling/child lists are still walked.
     * Called from {@code ChatHudMixin} when fancyChat is enabled.
     */
    public Component withFancyChat(Component message) {
        if (!isEnabled() || !fancyChat.get()) {
            return message;
        }
        return fancyComponent(message);
    }

    private static MutableComponent fancyComponent(Component src) {
        MutableComponent result;
        if (src.getContents() instanceof PlainTextContents.LiteralContents lc) {
            result = Component.literal(toFancy(lc.text())).withStyle(src.getStyle());
        } else {
            // Keep non-literal contents (translations, scores, selectors…) as-is.
            result = src.copy();
        }
        // copy() clones siblings, so clear them and re-add the transformed versions.
        result.getSiblings().clear();
        for (Component sibling : src.getSiblings()) {
            result.append(fancyComponent(sibling));
        }
        return result;
    }

    /**
     * Wrap an incoming chat line's whole component tree in a Style pointing
     * at the configured font, so every word in the line (including the
     * timestamp we may have just prepended) renders with it - child
     * components without their own explicit font inherit this one. "default"
     * leaves vanilla's own font alone. Called from {@code ChatHudMixin}.
     */
    public Component withFont(Component message) {
        if (!isEnabled()) {
            return message;
        }
        FontDescription fontDesc = parseFont(font.get());
        if (fontDesc == null) {
            return message;
        }
        return message.copy().withStyle(Style.EMPTY.withFont(fontDesc));
    }

    /**
     * "default" (or blank) means "don't override". A bare word like "uniform"
     * is assumed to be a vanilla font under the minecraft namespace; anything
     * with a ':' is taken as a full namespace:path resource location, so a
     * resource pack's own custom font also works. Invalid text just renders
     * with vanilla's fallback glyphs rather than crashing.
     */
    private static FontDescription parseFont(String raw) {
        if (raw == null || raw.isEmpty() || raw.equalsIgnoreCase("default")) {
            return null;
        }
        try {
            Identifier id = raw.indexOf(':') >= 0 ? Identifier.parse(raw) : Identifier.withDefaultNamespace(raw);
            return new FontDescription.Resource(id);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Push nobackground's effect out to vanilla's actual chat background
     * opacity option, saving/restoring the previous value so turning it back
     * off doesn't permanently clobber the user's own opacity setting.
     */
    private void applyBackgroundOpacity() {
        Options options = MultiKeyBindingManager.getGameOptions();
        if (options == null) {
            us.kenny.MultiKeyBindingClient.LOGGER.warn("[ev0l] applyBackgroundOpacity: gameOptions is null, can't apply");
            return;
        }
        double before = options.textBackgroundOpacity().get();
        if (noBackground.get()) {
            if (savedBackgroundOpacity == null) {
                savedBackgroundOpacity = before;
            }
            options.textBackgroundOpacity().set(0.0);
        } else if (savedBackgroundOpacity != null) {
            options.textBackgroundOpacity().set(savedBackgroundOpacity);
            savedBackgroundOpacity = null;
        }
        double after = options.textBackgroundOpacity().get();
        us.kenny.MultiKeyBindingClient.LOGGER.info(
                "[ev0l] applyBackgroundOpacity: noBackground={} before={} after={} saved={}",
                noBackground.get(), before, after, savedBackgroundOpacity);
    }

    private static String toFancy(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            int index = LOWER.indexOf(Character.toLowerCase(c));
            out.append(index >= 0 ? SMALL_CAPS.charAt(index) : c);
        }
        return out.toString();
    }
}
