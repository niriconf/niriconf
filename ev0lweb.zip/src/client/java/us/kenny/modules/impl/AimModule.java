package us.kenny.modules.impl;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import us.kenny.modules.Ev0lModule;
import us.kenny.modules.settings.BooleanModuleSetting;
import us.kenny.modules.settings.MultiSelectModuleSetting;
import us.kenny.modules.settings.NumberModuleSetting;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Smoothly turns the player's view toward a nearby entity, driven off the
 * render loop's wall-clock frame time rather than the 20Hz game tick, so
 * the turn rate stays smooth regardless of tick lag or frame rate. Which
 * entities count as targets is configurable from the web UI ({@code
 * targets}, a multi-select of entity types); how the turning itself behaves
 * is split into independent yaw/pitch toggles, speeds, and "stop on hitbox"
 * settings so it can be tuned anywhere from a subtle assist to a hard snap.
 */
public final class AimModule extends Ev0lModule {
    public static final AimModule INSTANCE = new AimModule();

    public final MultiSelectModuleSetting targets =
            new MultiSelectModuleSetting("targets", "Entity types to aim at", buildEntityOptions(), List.of());
    public final NumberModuleSetting range =
            new NumberModuleSetting("range", "Maximum distance from the player's eyes, in blocks, that an entity can be targeted from", 6.0, 1.0, 64.0);
    public final BooleanModuleSetting aimHorizontally =
            new BooleanModuleSetting("aim-horizontally", "Rotate yaw (left/right) toward the target", true);
    public final BooleanModuleSetting aimVertically =
            new BooleanModuleSetting("aim-vertically", "Rotate pitch (up/down) toward the target", true);
    public final BooleanModuleSetting stopOnHitboxHorizontal = new BooleanModuleSetting(
            "stop-on-hitbox-horizontal",
            "Treat the target's hitbox edge as \"close enough\" horizontally: yaw eases toward whichever is closer, the hitbox edge or dead-center, instead of always snapping to dead-center",
            true);
    public final BooleanModuleSetting stopOnHitboxVertical = new BooleanModuleSetting(
            "stop-on-hitbox-vertical",
            "Treat the target's hitbox edge as \"close enough\" vertically: pitch eases toward whichever is closer, the hitbox edge or dead-center, instead of always snapping to dead-center",
            true);
    public final BooleanModuleSetting aimAtLastHit = new BooleanModuleSetting(
            "aim-at-last-hit",
            "Keep aiming at the entity you last attacked instead of retargeting to whichever selected entity is nearest",
            false);
    public final NumberModuleSetting aimSpeedHorizontal = new NumberModuleSetting(
            "aim-speed-horizontal", "Horizontal (yaw) turn speed, in degrees per second", 180.0, 0.0, 3600.0);
    public final NumberModuleSetting aimSpeedVertical = new NumberModuleSetting(
            "aim-speed-vertical", "Vertical (pitch) turn speed, in degrees per second", 180.0, 0.0, 3600.0);

    /** Last entity the player attacked, for {@link #aimAtLastHit}. */
    private Entity lastHitEntity;

    /**
     * Wall-clock timestamp of the previous frame this module actually turned
     * the player, so the turn step can be scaled to real elapsed time
     * instead of a fixed per-tick amount. Reset to -1 whenever aiming
     * stops (module disabled, no target, menu open) so the very first frame
     * after resuming doesn't apply a huge step built up while idle.
     */
    private long lastFrameNanos = -1L;

    private AimModule() {
        super("aim", "Assists aiming by smoothly turning toward nearby entities", false);
        registerSetting(targets);
        registerSetting(range);
        registerSetting(aimHorizontally);
        registerSetting(aimVertically);
        registerSetting(stopOnHitboxHorizontal);
        registerSetting(stopOnHitboxVertical);
        registerSetting(aimAtLastHit);
        registerSetting(aimSpeedHorizontal);
        registerSetting(aimSpeedVertical);
    }

    /**
     * Wires up the attack-tracking callback. Called once from {@code
     * MultiKeyBindingClient.onInitializeClient()}. The per-frame rotation
     * step itself is driven by {@code MinecraftClientMixin} calling
     * {@link #onFrame()} directly, rather than a Fabric API event, so this
     * module doesn't depend on a specific rendering-events module being
     * present on whatever Fabric API version the project is built against.
     */
    public static void register() {
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            INSTANCE.lastHitEntity = entity;
            return InteractionResult.PASS;
        });
    }

    /** Called once per rendered frame by {@code MinecraftClientMixin}. */
    public void onFrame() {
        Minecraft client = Minecraft.getInstance();
        if (!isEnabled() || client.player == null || client.level == null || client.screen != null) {
            lastFrameNanos = -1L;
            return;
        }
        if (!aimHorizontally.get() && !aimVertically.get()) {
            lastFrameNanos = -1L;
            return;
        }

        Entity target = pickTarget(client);
        if (target == null) {
            lastFrameNanos = -1L;
            return;
        }

        long now = System.nanoTime();
        if (lastFrameNanos < 0L) {
            // First frame back after being idle: establish a baseline instead of
            // applying a step for however long it's been since the last frame.
            lastFrameNanos = now;
            return;
        }
        // Cap the step so a lag spike or alt-tab doesn't translate into one huge jump.
        double deltaSeconds = Math.min((now - lastFrameNanos) / 1_000_000_000.0, 0.25);
        lastFrameNanos = now;

        Player player = client.player;
        Vec3 eye = player.getEyePosition();
        AABB box = target.getBoundingBox();
        Vec3 center = box.getCenter();

        double dx = center.x - eye.x;
        double dy = center.y - eye.y;
        double dz = center.z - eye.z;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        double distance = Math.sqrt(horizontalDist * horizontalDist + dy * dy);
        if (distance < 1.0e-4) {
            return;
        }

        double yawCenter = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double pitchCenter = -Math.toDegrees(Math.atan2(dy, horizontalDist));

        float yaw = player.getYRot();
        float pitch = player.getXRot();

        if (aimHorizontally.get()) {
            double halfWidthAngle = Math.toDegrees(Math.atan2(box.getXsize() / 2.0, Math.max(horizontalDist, 1.0e-4)));
            double yawTarget = stopOnHitboxHorizontal.get()
                    ? nearestInBounds(yaw, yawCenter, halfWidthAngle)
                    : yawCenter;
            float maxDeltaYaw = (float) (aimSpeedHorizontal.get() * deltaSeconds);
            yaw = step(yaw, (float) yawTarget, maxDeltaYaw);
        }
        if (aimVertically.get()) {
            double halfHeightAngle = Math.toDegrees(Math.atan2(box.getYsize() / 2.0, Math.max(distance, 1.0e-4)));
            double pitchTarget = stopOnHitboxVertical.get()
                    ? nearestInBounds(pitch, pitchCenter, halfHeightAngle)
                    : pitchCenter;
            float maxDeltaPitch = (float) (aimSpeedVertical.get() * deltaSeconds);
            pitch = step(pitch, (float) pitchTarget, maxDeltaPitch);
            pitch = Math.max(-90.0f, Math.min(90.0f, pitch));
        }

        player.setYRot(yaw);
        player.setXRot(pitch);
        // Keep the head/body rotation fields driving third-person rendering and
        // server-bound look packets in sync, same as vanilla mouse input does.
        player.yHeadRot = yaw;
        player.yBodyRot = yaw;
    }

    private Entity pickTarget(Minecraft client) {
        Player player = client.player;
        Set<String> selected = targets.get();
        if (selected.isEmpty()) {
            return null;
        }

        double rangeBlocks = range.get();
        if (aimAtLastHit.get() && lastHitEntity != null && isValidTarget(lastHitEntity, player, selected, rangeBlocks)) {
            return lastHitEntity;
        }

        Vec3 eye = player.getEyePosition();
        AABB searchBox = new AABB(eye, eye).inflate(rangeBlocks);

        Entity closest = null;
        double closestDistSq = Double.MAX_VALUE;
        for (Entity entity : client.level.getEntities(player, searchBox,
                e -> isValidTarget(e, player, selected, rangeBlocks))) {
            double distSq = entity.distanceToSqr(player);
            if (distSq < closestDistSq) {
                closestDistSq = distSq;
                closest = entity;
            }
        }
        return closest;
    }

    private boolean isValidTarget(Entity entity, Player player, Set<String> selected, double rangeBlocks) {
        if (entity == player || !entity.isAlive()) {
            return false;
        }
        if (!selected.contains(entityKey(entity))) {
            return false;
        }
        return entity.distanceToSqr(player) <= rangeBlocks * rangeBlocks;
    }

    private static String entityKey(Entity entity) {
        return entity instanceof Player ? "minecraft:player"
                : BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString();
    }

    /**
     * The point closest to {@code current} within {@code center ± halfSpan}.
     * When {@code current} is already inside that span, this returns {@code
     * current} itself (zero correction), so crossing the hitbox edge is
     * continuous rather than the discontinuous "fully on target, then
     * suddenly correcting all the way to dead-center" jump a binary
     * inside/outside check produces.
     */
    private static double nearestInBounds(float current, double center, double halfSpan) {
        double offset = wrapDegrees(current - center);
        double clampedOffset = Math.max(-halfSpan, Math.min(halfSpan, offset));
        return center + clampedOffset;
    }

    /** Turns {@code current} toward {@code target} by at most {@code maxDelta} degrees. */
    private static float step(float current, float target, float maxDelta) {
        if (maxDelta <= 0.0f) {
            return current;
        }
        float delta = wrapDegrees(target - current);
        if (Math.abs(delta) <= maxDelta) {
            return current + delta;
        }
        return current + Math.copySign(maxDelta, delta);
    }

    private static float wrapDegrees(float degrees) {
        float wrapped = degrees % 360.0f;
        if (wrapped >= 180.0f) {
            wrapped -= 360.0f;
        } else if (wrapped < -180.0f) {
            wrapped += 360.0f;
        }
        return wrapped;
    }

    private static double wrapDegrees(double degrees) {
        double wrapped = degrees % 360.0;
        if (wrapped >= 180.0) {
            wrapped -= 360.0;
        } else if (wrapped < -180.0) {
            wrapped += 360.0;
        }
        return wrapped;
    }

    /**
     * "minecraft:player" plus every registered entity type, excluding
     * {@link MobCategory#MISC} (boats, item frames, experience orbs, etc.)
     * since those aren't sensible aim targets.
     */
    private static List<String> buildEntityOptions() {
        List<String> options = new ArrayList<>();
        options.add("minecraft:player");
        for (EntityType<?> type : BuiltInRegistries.ENTITY_TYPE) {
            if (type.getCategory() == MobCategory.MISC) {
                continue;
            }
            options.add(BuiltInRegistries.ENTITY_TYPE.getKey(type).toString());
        }
        return options;
    }
}
