package us.kenny.core;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.UUID;
import java.util.function.BooleanSupplier;
import net.minecraft.client.KeyMapping.Category;

public class StickyMultiKeyBinding extends MultiKeyBinding {
    private final BooleanSupplier toggleGetter;
    private boolean releasedByScreenWhenDown; // Toggle was released by opening a screen
    private final boolean shouldRestore; // Should toggle be restored after ^ screen is closed?

    public StickyMultiKeyBinding(UUID id, String action, Category category, InputConstants.Key key,
            BooleanSupplier toggleGetter, boolean shouldRestore) {
        super(id, action, category, key);
        this.toggleGetter = toggleGetter;
        this.shouldRestore = shouldRestore;
    }

    public boolean isToggleMode() {
        return this.toggleGetter.getAsBoolean();
    }

    /**
     * Set the pressed state directly. Used to keep sibling toggle bindings of the
     * same action in sync after one of them flips.
     */
    public void forceSetPressed(boolean pressed) {
        super.setPressed(pressed);
    }

    @Override
    public void setPressed(boolean pressed) {
        if (this.toggleGetter.getAsBoolean()) {
            if (pressed) {
                super.setPressed(!this.getPressed());
            }
        } else {
            super.setPressed(pressed);
        }
    }

    @Override
    public void release() {
        if (this.toggleGetter.getAsBoolean() && this.getPressed() || this.releasedByScreenWhenDown) {
            this.releasedByScreenWhenDown = true;
        }

        this.untoggle();
    }

    public boolean shouldSetOnIngameFocus() {
        return super.shouldSetOnIngameFocus() && !this.toggleGetter.getAsBoolean();
    }

    public boolean shouldRestoreStateOnScreenClosed() {
        boolean bl = this.shouldRestore && this.toggleGetter.getAsBoolean()
                && this.getKey().getType() == InputConstants.Type.KEYSYM && this.releasedByScreenWhenDown;
        this.releasedByScreenWhenDown = false;
        return bl;
    }

    public void untoggle() {
        super.setPressed(false);
    }
}
