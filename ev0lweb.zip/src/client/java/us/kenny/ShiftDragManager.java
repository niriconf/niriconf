package us.kenny;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.FurnaceResultSlot;
import net.minecraft.world.inventory.MerchantResultSlot;
import net.minecraft.world.inventory.ResultSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;
import us.kenny.mixin.AbstractContainerScreenAccessor;
import us.kenny.modules.impl.ShiftDragModule;

/**
 * Tracks shift+LMB drag state across an inventory screen.
 * When the player holds shift and left-click-drags across slots,
 * each newly entered slot is shift-clicked (QUICK_MOVE).
 */
public class ShiftDragManager {

    private static Slot lastSlot = null;
    private static boolean active = false;

    /** Call when LMB is pressed inside a container screen. */
    public static void onMousePressed(AbstractContainerScreen<?> screen, double x, double y) {
        if (!ShiftDragModule.INSTANCE.isEnabled()) return;

        AbstractContainerScreenAccessor acc = (AbstractContainerScreenAccessor) screen;
        lastSlot = acc.mkb$getHoveredSlot(x, y);
        // Only activate if shift is held and the mouse has nothing on it
        // (if there's an item on the cursor vanilla drag-split should take over)
        Minecraft mc = Minecraft.getInstance();
        boolean shiftHeld = isShiftDown(mc);
        ItemStack carried = mc.player.containerMenu.getCarried();
        active = shiftHeld && carried.isEmpty();
    }

    /** Call when LMB is released inside a container screen. */
    public static void onMouseReleased() {
        active = false;
        lastSlot = null;
    }

    /**
     * Call during an LMB drag inside a container screen.
     * Returns true if the event was consumed (slot was shift-clicked by us).
     */
    public static boolean onMouseDragged(AbstractContainerScreen<?> screen, double x, double y) {
        if (!active || !ShiftDragModule.INSTANCE.isEnabled()) return false;

        Minecraft mc = Minecraft.getInstance();
        if (!isShiftDown(mc)) {
            active = false;
            lastSlot = null;
            return false;
        }

        AbstractContainerScreenAccessor acc = (AbstractContainerScreenAccessor) screen;
        Slot hovered = acc.mkb$getHoveredSlot(x, y);

        // Nothing new to do if same slot or no slot
        if (hovered == null || hovered == lastSlot) return false;

        lastSlot = hovered;

        // Don't act on empty slots or crafting output slots
        ItemStack slotStack = hovered.getItem();
        if (slotStack.isEmpty()) return false;
        if (isCraftingOutput(hovered)) return false;

        // Nothing should be on the cursor (double-check; user may have clicked
        // something that picked up an item before dragging)
        ItemStack carried = mc.player.containerMenu.getCarried();
        if (!carried.isEmpty()) {
            active = false;
            return false;
        }

        // Shift-click the slot
        acc.mkb$slotClicked(hovered, hovered.index, 0, ClickType.QUICK_MOVE);
        return true;
    }

    private static boolean isShiftDown(Minecraft mc) {
        com.mojang.blaze3d.platform.Window win = mc.getWindow();
        return InputConstants.isKeyDown(win, GLFW.GLFW_KEY_LEFT_SHIFT)
            || InputConstants.isKeyDown(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    private static boolean isCraftingOutput(Slot slot) {
        return slot instanceof ResultSlot
            || slot instanceof FurnaceResultSlot
            || slot instanceof MerchantResultSlot;
    }
}
